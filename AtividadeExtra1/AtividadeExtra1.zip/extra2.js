const aero = (a, b) => a + b;

const resultado = aero(5, 8);

console.log(`O resultado é: ${resultado}`); 

// O que vai ser exibido aqui?

// Resposta: Será exibido "O resultado é: 13"